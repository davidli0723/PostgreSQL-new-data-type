CREATE TABLE Students (
	id      INT,
	name    varchar(20),
	postadd PostAddress,
	program INT,
	plan    char(6),
	primary key (id)
);