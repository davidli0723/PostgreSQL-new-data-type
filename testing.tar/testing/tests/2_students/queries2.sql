-- Tests on values of the PostAddress data type

\echo
\echo -- Running some queries --
\echo

\echo
\echo -- Count students
\echo

select count(*)
from   Students;

\echo
\echo -- Lookup on Students using id and postadd
\echo

select *
from   Students
where  id=3022053; -- exists

select *
from   Students
where  id=3026356; -- exists

select *
from   Students
where  id=3111111; -- doesn't exist

select count(*)
from   Students
where  postadd = 'U11/338 Market Rd, Lakeside, AU 7756'::PostAddress; -- exists

select count(*)
from   Students
where  postadd = 'U46/177 Church St, Central, AR 7349'::PostAddress; -- exists


select count(*)
from   Students
where  postadd = '427 Market Ave, Northside, EL 8485'::PostAddress; -- does not exist

\echo
\echo -- Check ordering for PostAddress
\echo

select *
from   Students
order  by postadd, id
limit  10;

select *
from   Students
order  by postadd desc, id
limit  10;

\echo
\echo -- Check grouping based on postadd (look for repeated postadds)
\echo

select show_postcode(postadd), show(postadd), count(*)
from   Students
group  by show_postcode(postadd), show(postadd) having count(*) > 1
order  by count(*) DESC, show_postcode(postadd), show(postadd) ASC
limit  20;

select show(postadd), count(*)
from   Students
group  by show(postadd) having count(*) > 1
order  by count(*) DESC, show(postadd) DESC
limit  20;

select show_unit(postadd), show(postadd), count(*)
from   Students
group  by show_unit(postadd), show(postadd) having count(*) > 1
order  by count(*) DESC, show_unit(postadd) DESC, show(postadd) ASC
limit  20;


