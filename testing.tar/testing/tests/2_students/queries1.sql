-- Check if it can generate and use indexes

\echo
\echo -- Check to see whether hash index works
\echo

create index students_postadd_idx on Students using hash (postadd);

explain analyze
select * from Students
where postadd = 'U38/272 King St, Westville, CE 1941'::PostAddress;

explain analyze
select * from Students
where postadd = 'U38/272 King St, Westville, AR 7393'::PostAddress;

drop index students_postadd_idx;




