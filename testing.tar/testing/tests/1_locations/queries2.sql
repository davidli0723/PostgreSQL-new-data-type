create index on Locations using hash (postadd);
SET enable_seqscan = OFF;
select * from Locations where postadd='U19/36 Queen Ave, Southgate, AR 7279';
explain select * from Locations where postadd='U19/36 Queen Ave, Southgate, AR 7279';
explain analyze select * from Locations where postadd='U19/36 Queen Ave, Southgate, AR 7279';
SET enable_seqscan = ON;