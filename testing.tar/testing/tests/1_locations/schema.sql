create table Locations (
	lid       SERIAL PRIMARY KEY,
	postadd   PostAddress
);
