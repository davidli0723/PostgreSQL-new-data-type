select a.postadd
from   Locations a join Locations b on (a.postadd = b.postadd)
order  by a.postadd;

select postadd,count(*)
from   Locations
group  by postadd
order  by show_postcode(postadd) ASC, postadd ASC;
