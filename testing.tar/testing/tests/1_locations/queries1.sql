select count(*) from Locations;
select * from Locations;
select show_postcode(postadd) from Locations;
select show_unit(postadd) from Locations;
select show(postadd) from Locations;
