select postadd
from Locations where postadd > 'U3/100 Victoria Ave, Lakeside, AU 5135';

select postadd
from Locations where postadd <= 'B33/240 Emerald Forest HWY, Hillsborough, NO 5865';

select postadd
from Locations where postadd <> '240 Emerald Forest HWY, Hillsborough, NO 5865';

select postadd
from Locations where postadd ~ 'U19/36 Queen Ave, Southgate, AR 7279';

select postadd
from Locations where postadd !~ 'U19/36 Queen Ave, Southgate, AR 7279';