\echo
\echo -- Checking valid PostAddresss ... expect to see addresses echoed as their input 
\echo



select 'U19/36 Queen Ave, Southgate, AR 7279'::PostAddress;
select 'U3/100 Victoria Ave, Lakeside, AU 5135'::PostAddress;
select 'B33/240 Emerald Forest HWY, Hillsborough, NO 5865'::PostAddress;
select '240 Emerald Forest HWY, Hillsborough, NO 5865'::PostAddress;
select 'u40/182 GEORgE ST, weStVILlE, AU 4203'::PostAddress;       
select 'U31/156 QUEEN St, wEStVIlLE, EL 2992'::PostAddress;        
select 'u15/173 eMerALd forest hWY, HIlLsBORougH, NO 5865'::PostAddress;        
select 'u35/76 MaRkeT ST, southgAtE, AR 7279'::PostAddress;       
select 'U13/39 KiNg aVE, LAKeSIDE, AR 4988'::PostAddress;      
select 'U27/432 gRand emPERor AvE, GrEenWOOd, ZE 5860'::PostAddress;     
select 'U3/190 MAiN hWy, sOUTHgaTe, NO 4486'::PostAddress;    
select 'u36/431 PArK RD, EAStOn, ZE 5499'::PostAddress; 
select 'U22/7 STaRliGHT rd, nOrtHsIde, AU 3024'::PostAddress;            
select 'U30/477 MAIN ST, EASToN, ZE 0549'::PostAddress;              







