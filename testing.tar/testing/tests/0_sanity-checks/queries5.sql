\echo
\echo -- Checking show_postcode(), show_unit(), show() ... 
\echo -- Expect to see addresses echo''''d in three forms: postcode, unit, short street name + state
\echo 
select show_postcode('U19/36 Queen Ave, Southgate, AR 7279'::PostAddress), show_unit('U19/36 Queen Ave, Southgate, AR 7279'::PostAddress), show('U19/36 Queen Ave, Southgate, AR 7279'::PostAddress);
select show_postcode('U3/100 Victoria Ave, Lakeside, AU 5135'::PostAddress), show_unit('U3/100 Victoria Ave, Lakeside, AU 5135'::PostAddress), show('U3/100 Victoria Ave, Lakeside, AU 5135'::PostAddress);
select show_postcode('U33/240 Emerald Forest HWY, Hillsborough, NO 5865'::PostAddress), show_unit('U33/240 Emerald Forest HWY, Hillsborough, NO 5865'::PostAddress), show('U33/240 Emerald Forest HWY, Hillsborough, NO 5865'::PostAddress);
select show_postcode('240 Emerald Forest HWY, Hillsborough, NO 5865'::PostAddress), show_unit('240 Emerald Forest HWY, Hillsborough, NO 5865'::PostAddress), show('240 Emerald Forest HWY, Hillsborough, NO 5865'::PostAddress);
select show_postcode('U13/39 KiNg aVE, LAKeSIDE, AR 4988'::PostAddress), show_unit('U13/39 KiNg aVE, LAKeSIDE, AR 4988'::PostAddress), show('U13/39 KiNg aVE, LAKeSIDE, AR 4988'::PostAddress);
select show_postcode('39 KiNg aVE, LAKeSIDE, AR 4988'::PostAddress), show_unit('39 KiNg aVE, LAKeSIDE, AR 4988'::PostAddress), show('39 KiNg aVE, LAKeSIDE, AR 4988'::PostAddress);
select show_postcode('U13/39 KiNg aVE, LAKeSIDE, AR 0988'::PostAddress), show_unit('U13/39 KiNg aVE, LAKeSIDE, AR 0988'::PostAddress), show('U13/39 KiNg aVE, LAKeSIDE, AR 0988'::PostAddress);
