\echo
\echo -- Checking relational operators ... tests below should return True --
\echo


select 'U19/36 Queen Ave, Southgate, AR 7279'::PostAddress = 'U19/36 Queen Ave, Southgate, AR 7279'::PostAddress;
select 'U19/36 Queen Ave, Southgate, AR 7279'::PostAddress = 'u19/36 queen ave, southgate, AR 7279'::PostAddress;
select 'u19/36 queen ave, southgate, AR 7279'::PostAddress = 'u19/36 queen ave, southgate, AR 7279'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress = 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress = 'U7/120 Broadway Ave, San francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress = 'U7/120 Broadway Ave, san Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress = 'U7/120 Broadway ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress = 'U7/120 broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress = 'u7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, ruth, CA 9615'::PostAddress < 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, AR 9410'::PostAddress < 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, east irvine, CA 9410'::PostAddress < 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/101 Broadway Ave, San Francisco, CA 9410'::PostAddress < 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 broadway Ave, San Francisco, CA 9410'::PostAddress < 'U7/120 Queen Ave, San Francisco, CA 9410'::PostAddress;
select 'b7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress < 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select '120 Broadway Ave, San Francisco, CA 9410'::PostAddress < 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress <= 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress <= 'U7/120 Broadway Ave, San francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress <= 'U7/120 Broadway Ave, san Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress <= 'U7/120 Broadway ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress <= 'U7/120 broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress <= 'u7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, ruth, CA 9615'::PostAddress <= 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, AR 9410'::PostAddress <= 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, east irvine, CA 9410'::PostAddress <= 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/101 Broadway Ave, San Francisco, CA 9410'::PostAddress <= 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 broadway Ave, San Francisco, CA 9410'::PostAddress <= 'U7/120 Queen Ave, San Francisco, CA 9410'::PostAddress;
select 'b7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress <= 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select '120 Broadway Ave, San Francisco, CA 9410'::PostAddress <= 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress > 'U7/120 Broadway Ave, ruth, CA 9615'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress > 'U7/120 Broadway Ave, San Francisco, AR 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress > 'U7/120 Broadway Ave, east irvine, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress > 'U7/101 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Queen Ave, San Francisco, CA 9410'::PostAddress > 'U7/120 broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress > 'b7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress > '120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress >= 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San francisco, CA 9410'::PostAddress >= 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, san Francisco, CA 9410'::PostAddress >= 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway ave, San Francisco, CA 9410'::PostAddress >= 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 broadway Ave, San Francisco, CA 9410'::PostAddress >= 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'u7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress >= 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress >= 'U7/120 Broadway Ave, ruth, CA 9615'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress >= 'U7/120 Broadway Ave, San Francisco, AR 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress >= 'U7/120 Broadway Ave, east irvine, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress >= 'U7/101 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Queen Ave, San Francisco, CA 9410'::PostAddress >= 'U7/120 broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress >= 'b7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress >= '120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, ruth, CA 9615'::PostAddress <> 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, AR 9410'::PostAddress <> 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, east irvine, CA 9410'::PostAddress <> 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/101 Broadway Ave, San Francisco, CA 9410'::PostAddress <> 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 broadway Ave, San Francisco, CA 9410'::PostAddress <> 'U7/120 Queen Ave, San Francisco, CA 9410'::PostAddress;
select 'b7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress <> 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select '120 Broadway Ave, San Francisco, CA 9410'::PostAddress <> 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress ~ 'U7/120 Broadway Ave, San francisco, CA 9410'::PostAddress;
select 'U21/133 Queen Ave, San Francisco, CA 9410'::PostAddress ~ 'U7/120 Broadway Ave, San francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, ruth, CA 9615'::PostAddress !~ 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;
select 'U7/120 Broadway Ave, San Francisco, SA 6842'::PostAddress !~ 'U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;



