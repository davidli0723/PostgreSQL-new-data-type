\echo
\echo -- Checking invalid PostAddress, should raise error message
\echo

select 'U19/ 36 Queen Ave, Southgate, AR 7279'::PostAddress;          -- Having space before or after'/'
select 'U19/Queen Ave, Southgate, AR 7279'::PostAddress;        -- Missing street number
select 'U19/36 Queen Ave, Southgate, A 7279'::PostAddress;        -- Incorrect state abbr.       
select '240 Emerald Forest HWY, Hillsborough, N3 5865'::PostAddress;         -- Incorrect state abbr.     
select 'U19/36 Queen Ave, Southgate, AR7279'::PostAddress;        -- Missing space between state abbreviation and postcode 
select 'U19/36 Queen Ave, Southgate, AR 72A9'::PostAddress;        -- Non-numeric postcode       
select '19/36 Queen Ave, Southgate, AR 7279'::PostAddress;       -- Invalid Unit
select '240 Emerald Forest HWY Hillsborough NO 5865'::PostAddress;    -- missing ','          
select '240 Emerald Forest HwY, Hillsborough, no 5865'::PostAddress;    -- lower case state 
select '7/120 Broadway, San Francisco, CA 9410'::PostAddress;          -- unit does not start with a letter 
select 'AB3/120 Broadway, San Francisco, CA 9410'::PostAddress;        -- unit starts with two letters
select 'A7-/120 Broadway, San Francisco, CA 9410'::PostAddress;        -- no symbols allowed in unit        
select '7U/120 Broadway, San Francisco, CA 9410'::PostAddress;         -- unit does not start with a letter       
select 'U7U/120 Broadway, San Francisco, CA 9410'::PostAddress;        -- extra letters after digits in unit     
select 'A3//120 Broadway, San Francisco, CA 9410'::PostAddress;        -- extra '/' between unit and street       
select '/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;       -- street starts with non digits 
select 'U7/-120 Broadway Ave, San Francisco, CA 9410'::PostAddress;    -- street starts with non digits          
select 'U7/a120 Broadway Ave, San Francisco, CA 9410'::PostAddress;    -- street starts with non digits 
select 'U7/1s20 Broadway Ave, San Francisco, CA 9410'::PostAddress;    -- first part of street includes non digits 
select 'U7/Broadway Ave, San Francisco, CA 9410'::PostAddress;         -- first part of street missing
select 'U7/120 Broadw2ay Ave, San Francisco, CA 9410'::PostAddress;    -- second part of street includes non letters 
select 'U7/120 Broadway /Ave, San Francisco, CA 9410'::PostAddress;    -- second part of street includes non letters 
select 'U7/120, San Francisco, CA 9410'::PostAddress;                  -- second part of street missing
select 'U7/120 Broadway Ave, San0 Francisco, CA 9410'::PostAddress;    -- suburb includes non letters 
select 'U7/120 Broadway Ave, San Francisco, Ca 9410'::PostAddress;     -- state includes lowercase letters
select 'U7/120 Broadway Ave, San Francisco, C0 9410'::PostAddress;     -- state includes non letters
select 'U7/120 Broadway Ave, San Francisco, C* 9410'::PostAddress;     -- state includes non letters
select 'U7/120 Broadway Ave, San Francisco, C 9410'::PostAddress;      -- state with fewer letters
select 'U7/120 Broadway Ave, San Francisco, CAP 9410'::PostAddress;    -- state with extra letters
select 'U7/120 Broadway Ave, San Francisco, CA 9A10'::PostAddress;     -- postcode includes non digits
select 'U7/120 Broadway Ave, San Francisco, CA 941%'::PostAddress;     -- postcode includes non digits
select 'U7/120 Broadway Ave, San Francisco, CA 941'::PostAddress;      -- postcode with fewer digits
select 'U7/120 Broadway Ave, San Francisco, CA 94103'::PostAddress;    -- postcode with extra digits
select 'U7/120Broadway Ave, San Francisco, CA 9410'::PostAddress;      -- missing space between first and second part of street
select 'U7/120 Broadway Ave,San Francisco, CA 9410'::PostAddress;      -- missing space before suburb
select 'U7/120 Broadway Ave, San Francisco,CA 9410'::PostAddress;      -- missing space before state
select 'U7/120 Broadway Ave, San Francisco, CA9410'::PostAddress;      -- missing space before postcode
select ' U7/120 Broadway Ave, San Francisco, CA 9410'::PostAddress;    -- extra space
select 'U7 /120 Broadway Ave, San Francisco, CA 9410'::PostAddress;    -- extra space
select 'U7/ 120 Broadway Ave, San Francisco, CA 9410'::PostAddress;    -- extra space
select 'U7/120  Broadway Ave, San Francisco, CA 9410'::PostAddress;    -- extra space
select 'U7/120 Broadway  Ave, San Francisco, CA 9410'::PostAddress;    -- extra space
select 'U7/120 Broadway Ave , San Francisco, CA 9410'::PostAddress;    -- extra space
select 'U7/120 Broadway Ave,  San Francisco, CA 9410'::PostAddress;    -- extra space
select 'U7/120 Broadway Ave, San  Francisco, CA 9410'::PostAddress;    -- extra space
select 'U7/120 Broadway Ave, San Francisco , CA 9410'::PostAddress;    -- extra space
select 'U7/120 Broadway Ave, San Francisco,  CA 9410'::PostAddress;    -- extra space
select 'U7/120 Broadway Ave, San Francisco, CA  9410'::PostAddress;    -- extra space
select 'U7/120 Broadway Ave, San Francisco, CA 9410 '::PostAddress;    -- extra space
select 'U7/, San Francisco, CA 9410'::PostAddress;                     -- empty street
select 'U7/120 Broadway Ave, , CA 9410'::PostAddress;                  -- empty suburb
select 'U7/120 Broadway Ave, San Francisco,  9410'::PostAddress;       -- empty state
select 'U7/120 Broadway Ave, San Francisco, CA '::PostAddress;         -- empty postcode
select 'U7/120, Broadway Ave, San Francisco, CA 9410'::PostAddress;     -- extra ',' 
select 'U7/120 Broadway, Ave, San Francisco, CA 9410'::PostAddress;     -- extra ','
select 'U7/120 Broadway Ave, San Francisco, CA, 9410'::PostAddress;     -- extra ','
select 'U7/120 Broadway Ave, San Francisco, CA 9410,'::PostAddress;     -- extra ','





    




