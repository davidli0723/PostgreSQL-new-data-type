-----------------------------
-- clean up the example
-----------------------------
DROP TYPE PostAddress CASCADE;
